import {
  users,
  services,
  orders,
  fundRequests,
  type User,
  type InsertUser,
  type Service,
  type InsertService,
  type Order,
  type InsertOrder,
  type FundRequest,
  type InsertFundRequest,
  type OrderWithDetails,
  type FundRequestWithUser,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserBalance(userId: number, newBalance: string): Promise<User>;

  // Services
  getServices(): Promise<Service[]>;
  getService(id: number): Promise<Service | undefined>;
  createService(service: InsertService): Promise<Service>;
  updateService(id: number, service: Partial<InsertService>): Promise<Service>;
  deleteService(id: number): Promise<void>;

  // Orders
  getOrders(): Promise<OrderWithDetails[]>;
  getUserOrders(userId: number): Promise<OrderWithDetails[]>;
  createOrder(order: InsertOrder & { userId: number; charge: string }): Promise<Order>;
  updateOrderStatus(id: number, status: string): Promise<Order>;

  // Fund Requests
  getFundRequests(): Promise<FundRequestWithUser[]>;
  getUserFundRequests(userId: number): Promise<FundRequestWithUser[]>;
  createFundRequest(request: InsertFundRequest & { userId: number }): Promise<FundRequest>;
  updateFundRequestStatus(id: number, status: string): Promise<FundRequest>;
}

export class DatabaseStorage implements IStorage {
  // Users
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async updateUserBalance(userId: number, newBalance: string): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ balance: newBalance })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  // Services
  async getServices(): Promise<Service[]> {
    return await db.select().from(services);
  }

  async getService(id: number): Promise<Service | undefined> {
    const [service] = await db.select().from(services).where(eq(services.id, id));
    return service;
  }

  async createService(service: InsertService): Promise<Service> {
    const [newService] = await db.insert(services).values(service).returning();
    return newService;
  }

  async updateService(id: number, updates: Partial<InsertService>): Promise<Service> {
    const [updatedService] = await db
      .update(services)
      .set(updates)
      .where(eq(services.id, id))
      .returning();
    return updatedService;
  }

  async deleteService(id: number): Promise<void> {
    await db.delete(services).where(eq(services.id, id));
  }

  // Orders
  async getOrders(): Promise<OrderWithDetails[]> {
    const allOrders = await db.query.orders.findMany({
      with: {
        service: true,
        user: true,
      },
      orderBy: [desc(orders.createdAt)],
    });
    return allOrders as OrderWithDetails[];
  }

  async getUserOrders(userId: number): Promise<OrderWithDetails[]> {
    const userOrders = await db.query.orders.findMany({
      where: eq(orders.userId, userId),
      with: {
        service: true,
        user: true,
      },
      orderBy: [desc(orders.createdAt)],
    });
    return userOrders as OrderWithDetails[];
  }

  async createOrder(order: InsertOrder & { userId: number; charge: string }): Promise<Order> {
    const [newOrder] = await db.insert(orders).values(order).returning();
    return newOrder;
  }

  async updateOrderStatus(id: number, status: string): Promise<Order> {
    const [updatedOrder] = await db
      .update(orders)
      .set({ status })
      .where(eq(orders.id, id))
      .returning();
    return updatedOrder;
  }

  // Fund Requests
  async getFundRequests(): Promise<FundRequestWithUser[]> {
    const requests = await db.query.fundRequests.findMany({
      with: {
        user: true,
      },
      orderBy: [desc(fundRequests.createdAt)],
    });
    return requests as FundRequestWithUser[];
  }

  async getUserFundRequests(userId: number): Promise<FundRequestWithUser[]> {
    const requests = await db.query.fundRequests.findMany({
      where: eq(fundRequests.userId, userId),
      with: {
        user: true,
      },
      orderBy: [desc(fundRequests.createdAt)],
    });
    return requests as FundRequestWithUser[];
  }

  async createFundRequest(request: InsertFundRequest & { userId: number }): Promise<FundRequest> {
    const [newRequest] = await db.insert(fundRequests).values(request).returning();
    return newRequest;
  }

  async updateFundRequestStatus(id: number, status: string): Promise<FundRequest> {
    const [updatedRequest] = await db
      .update(fundRequests)
      .set({ status })
      .where(eq(fundRequests.id, id))
      .returning();
    return updatedRequest;
  }
}

export const storage = new DatabaseStorage();
