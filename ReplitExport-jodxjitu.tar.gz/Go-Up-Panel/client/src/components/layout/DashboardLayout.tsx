import { ReactNode } from "react";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "./AppSidebar";
import { useAuth } from "@/hooks/use-auth";
import { formatINR } from "@/lib/format";
import { Loader2, Wallet } from "lucide-react";
import { Redirect } from "wouter";

export function DashboardLayout({ children }: { children: ReactNode }) {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="h-screen w-screen flex items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    return <Redirect to="/auth" />;
  }

  return (
    <SidebarProvider style={{ "--sidebar-width": "16rem" } as React.CSSProperties}>
      <div className="flex h-screen w-full bg-background overflow-hidden selection:bg-primary/20">
        <AppSidebar />
        <div className="flex flex-col flex-1 min-w-0">
          <header className="h-16 flex items-center justify-between px-6 glass-panel shrink-0 z-10 relative">
            <div className="flex items-center gap-4">
              <SidebarTrigger className="hover:bg-secondary/80 text-muted-foreground hover:text-foreground transition-colors" />
              <h2 className="text-lg font-semibold tracking-tight hidden sm:block">
                Welcome back, <span className="text-primary">{user.username}</span>
              </h2>
            </div>
            <div className="flex items-center gap-3 bg-secondary/30 border border-border/50 px-4 py-2 rounded-full shadow-inner">
              <Wallet className="h-4 w-4 text-primary" />
              <span className="text-sm font-medium text-muted-foreground">Balance:</span>
              <span className="text-sm font-bold text-foreground">{formatINR(user.balance)}</span>
            </div>
          </header>
          <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 bg-background/50 relative">
            {/* Subtle light effects behind content */}
            <div className="absolute top-0 left-1/4 w-96 h-96 bg-primary/5 rounded-full blur-[100px] pointer-events-none" />
            <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-accent/5 rounded-full blur-[100px] pointer-events-none" />
            <div className="relative z-0 max-w-6xl mx-auto">
              {children}
            </div>
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}
