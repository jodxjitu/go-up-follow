import { Switch, Route, Redirect } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";

import Home from "@/pages/Home";
import AuthPage from "@/pages/Auth";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import Dashboard from "@/pages/Dashboard";
import NewOrder from "@/pages/NewOrder";
import Services from "@/pages/Services";
import Orders from "@/pages/Orders";
import AddFunds from "@/pages/AddFunds";
import Support from "@/pages/Support";

function ProtectedRoutes() {
  return (
    <DashboardLayout>
      <Switch>
        <Route path="/dashboard" component={Dashboard} />
        <Route path="/new-order" component={NewOrder} />
        <Route path="/services" component={Services} />
        <Route path="/orders" component={Orders} />
        <Route path="/add-funds" component={AddFunds} />
        <Route path="/support" component={Support} />
        <Route>
          <Redirect to="/dashboard" />
        </Route>
      </Switch>
    </DashboardLayout>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/auth" component={AuthPage} />
      <Route path="/dashboard" component={ProtectedRoutes} />
      <Route path="/new-order" component={ProtectedRoutes} />
      <Route path="/services" component={ProtectedRoutes} />
      <Route path="/orders" component={ProtectedRoutes} />
      <Route path="/add-funds" component={ProtectedRoutes} />
      <Route path="/support" component={ProtectedRoutes} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
