import { useState, useMemo } from "react";
import { useForm, useWatch } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useServices } from "@/hooks/use-services";
import { useCreateOrder } from "@/hooks/use-orders";
import { useToast } from "@/hooks/use-toast";
import { api } from "@shared/routes";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { formatINR } from "@/lib/format";
import { Loader2, Receipt } from "lucide-react";
import { useLocation } from "wouter";

export default function NewOrder() {
  const { data: services, isLoading } = useServices();
  const { mutateAsync: createOrder, isPending } = useCreateOrder();
  const { toast } = useToast();
  const [_, setLocation] = useLocation();

  const form = useForm<z.infer<typeof api.orders.create.input>>({
    resolver: zodResolver(api.orders.create.input),
    defaultValues: { serviceId: undefined, link: "", quantity: 1000 },
  });

  const serviceId = useWatch({ control: form.control, name: "serviceId" });
  const quantity = useWatch({ control: form.control, name: "quantity" }) || 0;

  const selectedService = useMemo(() => 
    services?.find(s => s.id === serviceId), 
  [services, serviceId]);

  const estimatedCost = useMemo(() => {
    if (!selectedService || !quantity) return 0;
    return (quantity / 1000) * parseFloat(selectedService.pricePer1000.toString());
  }, [selectedService, quantity]);

  const onSubmit = async (data: z.infer<typeof api.orders.create.input>) => {
    try {
      await createOrder({ ...data, quantity: Number(data.quantity) });
      toast({ title: "Order Placed Successfully!", description: "Check your order history for status." });
      setLocation("/orders");
    } catch (error: any) {
      toast({ title: "Failed to place order", description: error.message, variant: "destructive" });
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight mb-2">New Order</h1>
        <p className="text-muted-foreground">Select a service, provide your link, and we'll handle the rest.</p>
      </div>

      <Card className="glass-card shadow-2xl border-primary/20 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full blur-[80px]" />
        
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Receipt className="h-5 w-5 text-primary" />
            Order Details
          </CardTitle>
          <CardDescription>Fill out the form below to place a new order.</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center py-12"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>
          ) : (
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                
                <FormField
                  control={form.control}
                  name="serviceId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Service</FormLabel>
                      <Select 
                        onValueChange={(val) => field.onChange(parseInt(val))} 
                        defaultValue={field.value?.toString()}
                      >
                        <FormControl>
                          <SelectTrigger className="h-14 bg-secondary/50 border-border/50 rounded-xl focus:ring-primary">
                            <SelectValue placeholder="Select a service" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent className="bg-popover border-border rounded-xl">
                          {services?.map((service) => (
                            <SelectItem key={service.id} value={service.id.toString()} className="py-3">
                              {service.name} <span className="text-primary ml-2 font-mono">({formatINR(service.pricePer1000)} / 1000)</span>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {selectedService && (
                  <div className="p-4 rounded-xl bg-primary/5 border border-primary/10 text-sm text-muted-foreground">
                    <strong className="text-foreground block mb-1">Description:</strong>
                    {selectedService.description}
                  </div>
                )}

                <FormField
                  control={form.control}
                  name="link"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Link (URL)</FormLabel>
                      <FormControl>
                        <Input placeholder="https://instagram.com/..." {...field} className="h-14 bg-secondary/50 border-border/50 rounded-xl focus-visible:ring-primary" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="quantity"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Quantity</FormLabel>
                      <FormControl>
                        <Input type="number" min="10" placeholder="1000" {...field} onChange={e => field.onChange(e.target.valueAsNumber)} className="h-14 bg-secondary/50 border-border/50 rounded-xl focus-visible:ring-primary" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="p-6 rounded-2xl bg-secondary border border-border flex items-center justify-between mt-8">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Total Charge</p>
                    <p className="text-xs text-muted-foreground mt-1">Based on ₹{formatINR(selectedService?.pricePer1000)} per 1000</p>
                  </div>
                  <div className="text-3xl font-bold text-gradient">
                    {formatINR(estimatedCost)}
                  </div>
                </div>

                <Button type="submit" className="w-full h-14 rounded-xl bg-gradient-to-r from-primary to-accent text-white font-bold text-lg hover:shadow-xl hover:shadow-primary/30 transition-all border-0" disabled={isPending || !serviceId}>
                  {isPending ? <Loader2 className="mr-2 h-5 w-5 animate-spin" /> : null}
                  Place Order
                </Button>

              </form>
            </Form>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
