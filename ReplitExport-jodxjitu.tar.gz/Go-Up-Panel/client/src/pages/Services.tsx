import { useState } from "react";
import { useServices, useCreateService, useUpdateService, useDeleteService } from "@/hooks/use-services";
import { useAuth } from "@/hooks/use-auth";
import { formatINR } from "@/lib/format";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, Plus, Edit, Trash2 } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { api } from "@shared/routes";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";

export default function Services() {
  const { data: services, isLoading } = useServices();
  const { user } = useAuth();
  const isAdmin = user?.isAdmin;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight mb-2">Services</h1>
          <p className="text-muted-foreground">Browse all available services and pricing.</p>
        </div>
        {isAdmin && <ServiceDialog mode="create" />}
      </div>

      <Card className="glass-card">
        <CardHeader>
          <CardTitle>Service List</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center py-12"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>
          ) : (
            <div className="rounded-xl border border-border/50 overflow-hidden bg-background/50">
              <Table>
                <TableHeader className="bg-secondary/50">
                  <TableRow className="border-border/50">
                    <TableHead className="w-[80px]">ID</TableHead>
                    <TableHead>Service</TableHead>
                    <TableHead className="hidden md:table-cell">Description</TableHead>
                    <TableHead className="text-right">Price per 1000</TableHead>
                    {isAdmin && <TableHead className="text-right w-[150px]">Actions</TableHead>}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {services?.map((service) => (
                    <TableRow key={service.id} className="border-border/50 hover:bg-secondary/20 transition-colors">
                      <TableCell className="font-mono text-muted-foreground text-xs">{service.id}</TableCell>
                      <TableCell className="font-medium">{service.name}</TableCell>
                      <TableCell className="hidden md:table-cell text-muted-foreground text-sm max-w-[300px] truncate">{service.description}</TableCell>
                      <TableCell className="text-right font-bold text-primary">{formatINR(service.pricePer1000)}</TableCell>
                      {isAdmin && (
                        <TableCell className="text-right space-x-2">
                          <ServiceDialog mode="edit" service={service} />
                          <DeleteServiceButton id={service.id} />
                        </TableCell>
                      )}
                    </TableRow>
                  ))}
                  {services?.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={isAdmin ? 5 : 4} className="text-center py-8 text-muted-foreground">
                        No services available at the moment.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function ServiceDialog({ mode, service }: { mode: 'create' | 'edit', service?: any }) {
  const [open, setOpen] = useState(false);
  const { mutateAsync: createService, isPending: isCreating } = useCreateService();
  const { mutateAsync: updateService, isPending: isUpdating } = useUpdateService();
  const { toast } = useToast();

  const form = useForm<z.infer<typeof api.services.create.input>>({
    resolver: zodResolver(api.services.create.input),
    defaultValues: {
      name: service?.name || "",
      description: service?.description || "",
      pricePer1000: service?.pricePer1000 || "",
    }
  });

  const onSubmit = async (data: z.infer<typeof api.services.create.input>) => {
    try {
      if (mode === 'create') {
        await createService({ ...data, pricePer1000: data.pricePer1000.toString() });
        toast({ title: "Service Created" });
      } else {
        await updateService({ id: service.id, data: { ...data, pricePer1000: data.pricePer1000.toString() } });
        toast({ title: "Service Updated" });
      }
      setOpen(false);
      form.reset();
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {mode === 'create' ? (
          <Button className="bg-primary hover:bg-primary/90 text-primary-foreground"><Plus className="mr-2 h-4 w-4" /> Add Service</Button>
        ) : (
          <Button variant="ghost" size="icon" className="h-8 w-8 text-blue-400 hover:text-blue-300 hover:bg-blue-400/10"><Edit className="h-4 w-4" /></Button>
        )}
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px] bg-card border-border rounded-xl">
        <DialogHeader>
          <DialogTitle>{mode === 'create' ? 'Create New Service' : 'Edit Service'}</DialogTitle>
        </DialogHeader>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 pt-4">
          <div className="space-y-2">
            <Label>Name</Label>
            <Input {...form.register("name")} className="bg-background border-border" />
          </div>
          <div className="space-y-2">
            <Label>Price per 1000 (₹)</Label>
            <Input type="number" step="0.01" {...form.register("pricePer1000")} className="bg-background border-border" />
          </div>
          <div className="space-y-2">
            <Label>Description</Label>
            <Textarea {...form.register("description")} className="bg-background border-border resize-none" rows={3} />
          </div>
          <Button type="submit" className="w-full" disabled={isCreating || isUpdating}>
            {isCreating || isUpdating ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : "Save Service"}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function DeleteServiceButton({ id }: { id: number }) {
  const { mutateAsync: deleteService, isPending } = useDeleteService();
  const { toast } = useToast();

  const onDelete = async () => {
    if (!confirm("Are you sure you want to delete this service?")) return;
    try {
      await deleteService(id);
      toast({ title: "Service Deleted" });
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  };

  return (
    <Button variant="ghost" size="icon" onClick={onDelete} disabled={isPending} className="h-8 w-8 text-red-400 hover:text-red-300 hover:bg-red-400/10">
      {isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Trash2 className="h-4 w-4" />}
    </Button>
  );
}
