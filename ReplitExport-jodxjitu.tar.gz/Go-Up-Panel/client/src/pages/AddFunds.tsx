import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useFunds, useCreateFundRequest, useUpdateFundStatus } from "@/hooks/use-funds";
import { useAuth } from "@/hooks/use-auth";
import { formatINR, formatDate } from "@/lib/format";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { api } from "@shared/routes";
import { Loader2, QrCode, CheckCircle, XCircle, Smartphone } from "lucide-react";
import { QRCodeSVG } from "qrcode.react";
import { useState, useEffect } from "react";

export default function AddFunds() {
  const { data: funds, isLoading } = useFunds();
  const { mutateAsync: createRequest, isPending: isCreating } = useCreateFundRequest();
  const { mutateAsync: updateStatus, isPending: isUpdating } = useUpdateFundStatus();
  const { user } = useAuth();
  const isAdmin = user?.isAdmin;
  const { toast } = useToast();

  const form = useForm<z.infer<typeof api.funds.create.input>>({
    resolver: zodResolver(api.funds.create.input),
    defaultValues: { amount: "", utrNumber: "" },
  });

  const amount = form.watch("amount");
  const [upiUrl, setUpiUrl] = useState("upi://pay?pa=jodxjitu@fam&pn=GoUpFollowPanel&cu=INR");

  useEffect(() => {
    const amt = parseFloat(amount);
    if (!isNaN(amt) && amt > 0) {
      setUpiUrl(`upi://pay?pa=jodxjitu@fam&pn=GoUpFollowPanel&am=${amt}&cu=INR`);
    } else {
      setUpiUrl("upi://pay?pa=jodxjitu@fam&pn=GoUpFollowPanel&cu=INR");
    }
  }, [amount]);

  const onSubmit = async (data: z.infer<typeof api.funds.create.input>) => {
    try {
      await createRequest(data);
      toast({ title: "Request Submitted", description: "Your fund request is pending approval." });
      form.reset();
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  };

  const handleStatus = async (id: number, status: "Approved" | "Rejected") => {
    if (!confirm(`Are you sure you want to mark this payment as ${status}?`)) return;
    try {
      await updateStatus({ id, status });
      toast({ title: `Payment ${status}` });
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  };

  return (
    <div className="space-y-8 max-w-6xl mx-auto">
      <div>
        <h1 className="text-3xl font-bold tracking-tight mb-2">{isAdmin ? "Manage Funds" : "Add Funds"}</h1>
        <p className="text-muted-foreground">{isAdmin ? "Approve or reject user payments." : "Deposit money into your account using UPI QR code."}</p>
      </div>

      {!isAdmin && (
        <div className="grid md:grid-cols-2 gap-6">
          <Card className="glass-card overflow-hidden relative">
            <div className="absolute top-0 right-0 w-32 h-32 bg-primary/10 rounded-full blur-[40px] pointer-events-none" />
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><QrCode className="h-5 w-5 text-primary" /> Scan to Pay</CardTitle>
              <CardDescription>Scan this QR code with any UPI app</CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col items-center justify-center space-y-6">
              <div className="bg-white p-4 rounded-2xl shadow-xl shadow-primary/10">
                <QRCodeSVG 
                  value={upiUrl} 
                  size={200}
                  level="H"
                  includeMargin={true}
                />
              </div>
              <div className="w-full bg-secondary/30 p-4 rounded-xl border border-border/50 text-center">
                <p className="text-sm text-muted-foreground mb-1">Payable Amount</p>
                <p className="text-2xl font-bold text-primary">{formatINR(amount || "0")}</p>
                <p className="text-xs text-muted-foreground mt-2 font-mono">UPI ID: jodxjitu@fam</p>
              </div>
              <Button 
                asChild
                className="w-full h-12 rounded-xl bg-gradient-to-r from-primary to-accent text-white font-bold hover:shadow-lg hover:shadow-primary/25 transition-all"
              >
                <a href={upiUrl}>
                  <Smartphone className="mr-2 h-5 w-5" />
                  Pay with UPI App
                </a>
              </Button>
            </CardContent>
          </Card>

          <Card className="glass-card">
            <CardHeader>
              <CardTitle>Payment Details</CardTitle>
              <CardDescription>Enter the amount and UTR after payment</CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="amount"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Enter Amount (₹)</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            placeholder="Example: 500" 
                            {...field} 
                            className="bg-secondary/50 h-12 rounded-xl border-border/50 text-lg" 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="utrNumber"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Payment UTR / Transaction ID</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="Example: 123456789012" 
                            {...field} 
                            className="bg-secondary/50 h-12 rounded-xl border-border/50 font-mono" 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <div className="pt-4">
                    <Button 
                      type="submit" 
                      className="w-full h-12 rounded-xl bg-white text-black hover:bg-gray-200 font-bold border-0" 
                      disabled={isCreating || !amount || parseFloat(amount) <= 0}
                    >
                      {isCreating ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : "Submit Payment for Verification"}
                    </Button>
                    <p className="text-[10px] text-center text-muted-foreground mt-4 uppercase tracking-widest">
                      Your balance will be updated after admin verification
                    </p>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>
        </div>
      )}

      <Card className="glass-card">
        <CardHeader>
          <CardTitle>{isAdmin ? "All Fund Requests" : "Your Previous Requests"}</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center py-12"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>
          ) : (
            <div className="rounded-xl border border-border/50 overflow-hidden bg-background/50 overflow-x-auto">
              <Table>
                <TableHeader className="bg-secondary/50">
                  <TableRow className="border-border/50">
                    <TableHead>ID</TableHead>
                    {isAdmin && <TableHead>User</TableHead>}
                    <TableHead>Method</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>UTR Number</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Date</TableHead>
                    {isAdmin && <TableHead className="text-right">Actions</TableHead>}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {funds?.map((req) => (
                    <TableRow key={req.id} className="border-border/50 hover:bg-secondary/20">
                      <TableCell className="font-mono text-muted-foreground text-xs">#{req.id}</TableCell>
                      {isAdmin && <TableCell className="font-medium text-primary">{req.user?.username}</TableCell>}
                      <TableCell>{req.paymentMethod}</TableCell>
                      <TableCell className="font-bold">{formatINR(req.amount)}</TableCell>
                      <TableCell className="font-mono text-xs text-muted-foreground">{req.utrNumber}</TableCell>
                      <TableCell>
                        <span className={`px-2.5 py-1 rounded-full text-xs font-semibold border ${
                          req.status === 'Approved' ? 'bg-green-500/10 text-green-500 border-green-500/20' : 
                          req.status === 'Rejected' ? 'bg-red-500/10 text-red-500 border-red-500/20' : 
                          'bg-yellow-500/10 text-yellow-500 border-yellow-500/20'
                        }`}>
                          {req.status}
                        </span>
                      </TableCell>
                      <TableCell className="text-muted-foreground text-sm whitespace-nowrap">{formatDate(req.createdAt)}</TableCell>
                      {isAdmin && (
                        <TableCell className="text-right space-x-2 whitespace-nowrap">
                          {req.status === 'Pending' && (
                            <>
                              <Button variant="ghost" size="icon" onClick={() => handleStatus(req.id, 'Approved')} disabled={isUpdating} className="h-8 w-8 text-green-400 hover:text-green-300 hover:bg-green-400/10">
                                <CheckCircle className="h-4 w-4" />
                              </Button>
                              <Button variant="ghost" size="icon" onClick={() => handleStatus(req.id, 'Rejected')} disabled={isUpdating} className="h-8 w-8 text-red-400 hover:text-red-300 hover:bg-red-400/10">
                                <XCircle className="h-4 w-4" />
                              </Button>
                            </>
                          )}
                        </TableCell>
                      )}
                    </TableRow>
                  ))}
                  {funds?.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={isAdmin ? 8 : 7} className="text-center py-8 text-muted-foreground">
                        No requests found.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
