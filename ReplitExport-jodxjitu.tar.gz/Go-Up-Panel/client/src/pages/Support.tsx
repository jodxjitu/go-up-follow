import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Instagram, Mail, LifeBuoy } from "lucide-react";

export default function Support() {
  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight mb-2">Support</h1>
        <p className="text-muted-foreground">Need help? Get in touch with our team.</p>
      </div>

      <div className="grid md:grid-cols-2 gap-6 mt-8">
        <Card className="glass-card hover:border-primary/50 transition-colors cursor-pointer group" onClick={() => window.open("https://instagram.com/go_up_follow_", "_blank")}>
          <CardContent className="p-8 flex flex-col items-center text-center">
            <div className="h-16 w-16 rounded-full bg-gradient-to-tr from-[#f9ce34] via-[#ee2a7b] to-[#6228d7] p-[2px] mb-6 group-hover:scale-110 transition-transform">
              <div className="w-full h-full bg-card rounded-full flex items-center justify-center">
                <Instagram className="h-8 w-8 text-white" />
              </div>
            </div>
            <h3 className="text-xl font-bold mb-2">Instagram Support</h3>
            <p className="text-sm text-muted-foreground mb-6">Fastest way to reach us. DM us your queries directly on Instagram.</p>
            <span className="inline-block px-6 py-3 rounded-full bg-gradient-to-r from-primary to-accent text-white font-bold text-sm shadow-lg shadow-primary/20 w-full">
              Contact on Instagram
            </span>
          </CardContent>
        </Card>

        <Card className="glass-card hover:border-accent/50 transition-colors">
          <CardContent className="p-8 flex flex-col items-center text-center">
            <div className="h-16 w-16 rounded-full bg-accent/20 border border-accent/30 flex items-center justify-center mb-6">
              <Mail className="h-8 w-8 text-accent" />
            </div>
            <h3 className="text-xl font-bold mb-2">Email Support</h3>
            <p className="text-sm text-muted-foreground mb-6">For business inquiries and detailed support requests.</p>
            <a href="mailto:goupfollow@gmail.com" className="inline-block px-6 py-3 rounded-full bg-secondary text-foreground font-bold text-sm border border-border/50 hover:bg-secondary/80 transition-colors w-full">
              goupfollow@gmail.com
            </a>
          </CardContent>
        </Card>
      </div>

      <div className="mt-12 p-6 rounded-2xl bg-secondary/30 border border-border/50 flex gap-4 items-start">
        <div className="p-2 rounded-lg bg-primary/10">
          <LifeBuoy className="h-6 w-6 text-primary" />
        </div>
        <div>
          <h4 className="font-bold text-lg mb-1">Frequently Asked Questions</h4>
          <p className="text-sm text-muted-foreground leading-relaxed">
            Before reaching out, check if your order is still within the delivery timeframe specified in the service description. 
            If a service drops after completion, please provide the Order ID when contacting support for a refill.
          </p>
        </div>
      </div>
    </div>
  );
}
