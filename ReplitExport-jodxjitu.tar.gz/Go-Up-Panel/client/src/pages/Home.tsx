import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowUpRight, Zap, Shield, Rocket, CheckCircle2 } from "lucide-react";
import { motion } from "framer-motion";

export default function Home() {
  return (
    <div className="min-h-screen bg-background overflow-hidden relative selection:bg-primary/20">
      {/* Dynamic Background */}
      <div className="absolute inset-0 z-0">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-primary/20 rounded-full blur-[120px]" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-accent/20 rounded-full blur-[120px]" />
      </div>

      <nav className="relative z-10 flex items-center justify-between px-6 py-6 max-w-7xl mx-auto">
        <div className="flex items-center gap-2">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-accent shadow-lg shadow-primary/25">
            <ArrowUpRight className="h-6 w-6 text-white" />
          </div>
          <span className="text-xl font-bold text-gradient">Go Up Follow</span>
        </div>
        <div className="flex gap-4">
          <Link href="/auth">
            <Button variant="ghost" className="hidden sm:flex text-muted-foreground hover:text-foreground">
              Sign In
            </Button>
          </Link>
          <Link href="/auth">
            <Button className="bg-gradient-to-r from-primary to-accent text-white shadow-lg shadow-primary/25 hover:shadow-primary/40 border-0">
              Get Started
            </Button>
          </Link>
        </div>
      </nav>

      <main className="relative z-10 max-w-7xl mx-auto px-6 pt-20 pb-32">
        <div className="text-center max-w-3xl mx-auto space-y-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <span className="px-4 py-1.5 rounded-full bg-primary/10 border border-primary/20 text-primary text-sm font-semibold inline-block mb-6 shadow-[0_0_15px_rgba(124,58,237,0.15)]">
              #1 Premium SMM Panel in India
            </span>
            <h1 className="text-5xl md:text-7xl font-bold tracking-tight leading-tight">
              Grow Your Social Presence <br />
              <span className="text-gradient">Faster Than Ever</span>
            </h1>
          </motion.div>

          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-lg text-muted-foreground"
          >
            Best and Cheapest SMM Panel. Premium quality services for Instagram, YouTube, Twitter, and more. Instant delivery and 24/7 support.
          </motion.p>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4"
          >
            <Link href="/auth">
              <Button size="lg" className="w-full sm:w-auto h-14 px-8 bg-gradient-to-r from-primary to-accent text-white shadow-xl shadow-primary/25 hover:shadow-2xl hover:shadow-primary/40 hover:-translate-y-1 transition-all duration-300 rounded-xl text-lg border-0">
                Start Boosting Now
              </Button>
            </Link>
            <Link href="/auth">
              <Button size="lg" variant="outline" className="w-full sm:w-auto h-14 px-8 glass-card hover:bg-white/5 transition-all duration-300 rounded-xl text-lg">
                View Services
              </Button>
            </Link>
          </motion.div>
        </div>

        <motion.div 
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.4 }}
          className="mt-32 grid grid-cols-1 md:grid-cols-3 gap-8"
        >
          {[
            { icon: Zap, title: "Instant Delivery", desc: "Our automated systems process your orders instantly after placement." },
            { icon: Shield, title: "Premium Quality", desc: "We provide highest quality profiles that look 100% genuine and real." },
            { icon: Rocket, title: "Cheapest Prices", desc: "Unbeatable prices in the market. More value for every Rupee spent." }
          ].map((feature, i) => (
            <div key={i} className="glass-card p-8 rounded-2xl flex flex-col items-start gap-4 hover:-translate-y-2 transition-transform duration-300">
              <div className="h-12 w-12 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center">
                <feature.icon className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-bold">{feature.title}</h3>
              <p className="text-muted-foreground leading-relaxed">{feature.desc}</p>
            </div>
          ))}
        </motion.div>
      </main>
      
      <footer className="relative z-10 border-t border-border/30 bg-background/50 backdrop-blur-md py-8 text-center text-muted-foreground">
        <p>© {new Date().getFullYear()} Go Up Follow Panel. All rights reserved.</p>
      </footer>
    </div>
  );
}
