import { useState } from "react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { ArrowUpRight, Loader2 } from "lucide-react";
import { motion } from "framer-motion";
import { api } from "@shared/routes";

export default function AuthPage() {
  const [_, setLocation] = useLocation();
  const { login, register, isLoggingIn, isRegistering } = useAuth();
  const { toast } = useToast();

  const loginForm = useForm<z.infer<typeof api.auth.login.input>>({
    resolver: zodResolver(api.auth.login.input),
    defaultValues: { username: "", password: "" },
  });

  const registerForm = useForm<z.infer<typeof api.auth.register.input>>({
    resolver: zodResolver(api.auth.register.input),
    defaultValues: { username: "", email: "", password: "" },
  });

  const onLogin = async (data: z.infer<typeof api.auth.login.input>) => {
    try {
      await login(data);
      setLocation("/dashboard");
    } catch (error: any) {
      toast({ title: "Login Failed", description: error.message, variant: "destructive" });
    }
  };

  const onRegister = async (data: z.infer<typeof api.auth.register.input>) => {
    try {
      await register(data);
      setLocation("/dashboard");
    } catch (error: any) {
      toast({ title: "Registration Failed", description: error.message, variant: "destructive" });
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background relative overflow-hidden p-4">
      <div className="absolute top-[-20%] left-[-10%] w-[60%] h-[60%] bg-primary/20 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[-20%] right-[-10%] w-[60%] h-[60%] bg-accent/20 rounded-full blur-[120px] pointer-events-none" />

      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.4 }}
        className="w-full max-w-md"
      >
        <div className="flex flex-col items-center mb-8">
          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-primary to-accent shadow-xl shadow-primary/30 mb-4">
            <ArrowUpRight className="h-8 w-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold tracking-tight">Welcome Back</h1>
          <p className="text-muted-foreground mt-2">Sign in or create an account to continue</p>
        </div>

        <div className="glass-card p-2 rounded-2xl shadow-2xl">
          <Tabs defaultValue="login" className="w-full">
            <TabsList className="grid w-full grid-cols-2 p-1 bg-secondary/50 rounded-xl mb-4">
              <TabsTrigger value="login" className="rounded-lg data-[state=active]:bg-card data-[state=active]:text-foreground data-[state=active]:shadow-md transition-all">Login</TabsTrigger>
              <TabsTrigger value="register" className="rounded-lg data-[state=active]:bg-card data-[state=active]:text-foreground data-[state=active]:shadow-md transition-all">Sign Up</TabsTrigger>
            </TabsList>
            
            <TabsContent value="login" className="p-4 pt-2 focus-visible:outline-none">
              <form onSubmit={loginForm.handleSubmit(onLogin)} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="login-username">Username</Label>
                  <Input id="login-username" {...loginForm.register("username")} className="bg-secondary/50 border-border/50 focus-visible:ring-primary h-12 rounded-xl" placeholder="johndoe" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="login-password">Password</Label>
                  <Input id="login-password" type="password" {...loginForm.register("password")} className="bg-secondary/50 border-border/50 focus-visible:ring-primary h-12 rounded-xl" placeholder="••••••••" />
                </div>
                <Button type="submit" className="w-full h-12 rounded-xl bg-gradient-to-r from-primary to-accent text-white font-bold hover:shadow-lg hover:shadow-primary/25 transition-all mt-2 border-0" disabled={isLoggingIn}>
                  {isLoggingIn ? <Loader2 className="h-5 w-5 animate-spin" /> : "Sign In"}
                </Button>
              </form>
            </TabsContent>

            <TabsContent value="register" className="p-4 pt-2 focus-visible:outline-none">
              <form onSubmit={registerForm.handleSubmit(onRegister)} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="reg-username">Username</Label>
                  <Input id="reg-username" {...registerForm.register("username")} className="bg-secondary/50 border-border/50 focus-visible:ring-primary h-12 rounded-xl" placeholder="johndoe" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="reg-email">Email</Label>
                  <Input id="reg-email" type="email" {...registerForm.register("email")} className="bg-secondary/50 border-border/50 focus-visible:ring-primary h-12 rounded-xl" placeholder="john@example.com" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="reg-password">Password</Label>
                  <Input id="reg-password" type="password" {...registerForm.register("password")} className="bg-secondary/50 border-border/50 focus-visible:ring-primary h-12 rounded-xl" placeholder="••••••••" />
                </div>
                <Button type="submit" className="w-full h-12 rounded-xl bg-gradient-to-r from-primary to-accent text-white font-bold hover:shadow-lg hover:shadow-primary/25 transition-all mt-2 border-0" disabled={isRegistering}>
                  {isRegistering ? <Loader2 className="h-5 w-5 animate-spin" /> : "Create Account"}
                </Button>
              </form>
            </TabsContent>
          </Tabs>
        </div>
      </motion.div>
    </div>
  );
}
