import { useOrders, useUpdateOrderStatus } from "@/hooks/use-orders";
import { useAuth } from "@/hooks/use-auth";
import { formatINR, formatDate } from "@/lib/format";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Loader2, CheckCircle, XCircle } from "lucide-react";

export default function Orders() {
  const { data: orders, isLoading } = useOrders();
  const { user } = useAuth();
  const isAdmin = user?.isAdmin;
  const { mutateAsync: updateStatus, isPending } = useUpdateOrderStatus();
  const { toast } = useToast();

  const handleStatus = async (id: number, status: "Completed" | "Cancelled") => {
    if (!confirm(`Are you sure you want to mark this order as ${status}?`)) return;
    try {
      await updateStatus({ id, status });
      toast({ title: `Order ${status}`, description: status === 'Cancelled' ? 'Funds refunded to user balance.' : '' });
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight mb-2">{isAdmin ? "All Orders" : "Order History"}</h1>
        <p className="text-muted-foreground">{isAdmin ? "Manage system orders." : "View all your past and active orders."}</p>
      </div>

      <Card className="glass-card">
        <CardHeader>
          <CardTitle>Orders</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center py-12"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>
          ) : (
            <div className="rounded-xl border border-border/50 overflow-hidden bg-background/50 overflow-x-auto">
              <Table>
                <TableHeader className="bg-secondary/50">
                  <TableRow className="border-border/50">
                    <TableHead className="w-[80px]">ID</TableHead>
                    {isAdmin && <TableHead>User</TableHead>}
                    <TableHead>Service</TableHead>
                    <TableHead>Link</TableHead>
                    <TableHead>Charge</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Date</TableHead>
                    {isAdmin && <TableHead className="text-right">Actions</TableHead>}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {orders?.map((order) => (
                    <TableRow key={order.id} className="border-border/50 hover:bg-secondary/20 transition-colors">
                      <TableCell className="font-mono text-muted-foreground text-xs">#{order.id}</TableCell>
                      {isAdmin && <TableCell className="font-medium text-primary">{order.user?.username}</TableCell>}
                      <TableCell className="font-medium max-w-[150px] truncate">{order.service?.name}</TableCell>
                      <TableCell className="text-muted-foreground max-w-[150px] truncate">{order.link}</TableCell>
                      <TableCell className="font-medium">{formatINR(order.charge)}</TableCell>
                      <TableCell>
                        <span className={`px-2.5 py-1 rounded-full text-xs font-semibold border ${
                          order.status === 'Completed' ? 'bg-green-500/10 text-green-500 border-green-500/20' : 
                          order.status === 'Cancelled' ? 'bg-red-500/10 text-red-500 border-red-500/20' : 
                          'bg-yellow-500/10 text-yellow-500 border-yellow-500/20'
                        }`}>
                          {order.status}
                        </span>
                      </TableCell>
                      <TableCell className="text-muted-foreground text-sm whitespace-nowrap">{formatDate(order.createdAt)}</TableCell>
                      {isAdmin && (
                        <TableCell className="text-right space-x-2 whitespace-nowrap">
                          {order.status === 'Pending' && (
                            <>
                              <Button variant="ghost" size="icon" onClick={() => handleStatus(order.id, 'Completed')} disabled={isPending} className="h-8 w-8 text-green-400 hover:text-green-300 hover:bg-green-400/10">
                                <CheckCircle className="h-4 w-4" />
                              </Button>
                              <Button variant="ghost" size="icon" onClick={() => handleStatus(order.id, 'Cancelled')} disabled={isPending} className="h-8 w-8 text-red-400 hover:text-red-300 hover:bg-red-400/10">
                                <XCircle className="h-4 w-4" />
                              </Button>
                            </>
                          )}
                        </TableCell>
                      )}
                    </TableRow>
                  ))}
                  {orders?.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={isAdmin ? 8 : 7} className="text-center py-8 text-muted-foreground">
                        No orders found.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
