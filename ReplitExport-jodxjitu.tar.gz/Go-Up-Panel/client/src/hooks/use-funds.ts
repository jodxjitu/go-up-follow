import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";

type FundInput = z.infer<typeof api.funds.create.input>;
type FundStatusUpdate = z.infer<typeof api.funds.updateStatus.input>;

export function useFunds() {
  return useQuery({
    queryKey: [api.funds.list.path],
    queryFn: async () => {
      const res = await apiRequest("GET", api.funds.list.path);
      return api.funds.list.responses[200].parse(await res.json());
    },
  });
}

export function useCreateFundRequest() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: FundInput) => {
      const res = await apiRequest("POST", api.funds.create.path, data);
      return api.funds.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.funds.list.path] });
    },
  });
}

export function useUpdateFundStatus() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, status }: { id: number; status: FundStatusUpdate["status"] }) => {
      const url = buildUrl(api.funds.updateStatus.path, { id });
      const res = await apiRequest("PATCH", url, { status });
      return api.funds.updateStatus.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.funds.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.auth.me.path] }); // update balance
    },
  });
}
