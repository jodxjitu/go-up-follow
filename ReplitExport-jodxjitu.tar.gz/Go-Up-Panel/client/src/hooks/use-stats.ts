import { useQuery } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { apiRequest } from "@/lib/queryClient";

export function useDashboardStats() {
  return useQuery({
    queryKey: [api.stats.dashboard.path],
    queryFn: async () => {
      const res = await apiRequest("GET", api.stats.dashboard.path);
      return api.stats.dashboard.responses[200].parse(await res.json());
    },
  });
}
