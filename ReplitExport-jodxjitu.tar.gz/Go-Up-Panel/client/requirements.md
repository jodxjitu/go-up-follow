## Packages
framer-motion | Page transitions, micro-interactions, and smooth animations
react-hook-form | Form state management and validation
@hookform/resolvers | Zod validation resolver for forms
lucide-react | High-quality icons
date-fns | Formatting dates for order history and funds

## Notes
- "Go Up Follow Panel" is a premium SMM Panel with a forced dark theme.
- All currency values are in INR (₹).
- Dashboard and standard pages are protected.
- Admin functionalities are revealed conditionally based on user.isAdmin.
- Wouter `<Link>` components must be used directly with classNames, no nested `<a>` tags.
